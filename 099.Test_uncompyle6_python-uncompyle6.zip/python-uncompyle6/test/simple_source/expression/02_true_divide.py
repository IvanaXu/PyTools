# Tests BINARY_TRUE_DIVIDE and INPLACE_TRUE_DIVIDE
from __future__ import division  # needed on 2.2 .. 2.7
x = len(__file__) / 1
x /= 1
