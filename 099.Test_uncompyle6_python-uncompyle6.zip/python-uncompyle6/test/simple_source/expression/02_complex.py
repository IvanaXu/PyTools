# From python2.7/json/tests/test_recursion.py
# Tests our Python marshal load_code_internal handles reading complex numbers,
# marshal type 'x'
x = 5j
