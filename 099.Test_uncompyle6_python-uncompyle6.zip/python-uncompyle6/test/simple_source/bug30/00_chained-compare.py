# From 3.0 asyncore.py
# This is RUNNABLE!
r, w, e = ([], [], [])
if [] == r == w == e:
    r = [1]
assert r == [1]
