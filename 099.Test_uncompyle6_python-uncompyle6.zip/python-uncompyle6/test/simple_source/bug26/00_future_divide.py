# From 2.7.17 fractions
"""Rational, infinite-precision, real numbers."""

from __future__ import division
