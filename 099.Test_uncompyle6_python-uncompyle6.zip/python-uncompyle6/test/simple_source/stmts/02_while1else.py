# From Python-3.5.2/Lib/multiprocessing/connection.py

def PipeClient(address):
    while 1:
        z = 2
    else:
        raise
    return

# From 2.6.9 sre.py
# Bug was parsing inner while1. Our massaging adds a COME_FROM
# possibly in the wrong place. When control flow is
# redone possibly all of this mess will disappear.
def _parse(source, state, this, group, char):
    while 1:
        if this:
            while 1:
                raise RuntimeError
        else:
            raise IndexError
    return
