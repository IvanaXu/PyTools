import time
import exclude
def hello():
    print("Hello world! timestamp=%f" % time.time())
    exclude.aloha()