import foo


def main():
    foo.hello()


if __name__ == '__main__':
    main()
