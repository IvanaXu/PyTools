
def aloha():
    print('aloha!')