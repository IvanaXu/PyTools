#ifndef __PYPROTECT_CONFIG_H__
#define __PYPROTECT_CONFIG_H__

#define PYPROTECT_KEY           "\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff"
#define PYPROTECT_IV            "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
#define PYPROTECT_EXT_NAME      ".pye"

//#define DEBUG

#endif
