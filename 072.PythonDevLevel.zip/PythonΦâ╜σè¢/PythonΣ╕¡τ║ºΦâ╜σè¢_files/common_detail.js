
$(function(){
    //初始化试题答案选择状态
    $("[id^='question_']").each(function(){
        var user_answer = $(this).attr("data-user-answer");
        var question_type = $(this).attr("data-type");
        if(question_type == 3){
            $(this).find('.detail-q-option textarea').html(user_answer.replace(/^-/, '').replace(/-$/,''));
        }else {
            $(this).find(".option-label input").each(function(){
                if(user_answer.indexOf('-'+$(this).val()+'-') >= 0){
                    this.checked = true;
                }
            });
        }

    });
    //翻页按钮事件
    $("[name='number_btn']").bind('click',function(){
        current_page = $(this).attr('data-value');
        check(current_page);
    });
    $("#pre_page").bind('click',function(){
        current_page = current_page > 1 ?  parseInt(current_page) - 1 : 1;
        check(current_page);
    });
    $("#next_page").bind('click',function(){
        current_page = current_page < max_page ?  parseInt(current_page) + 1 : max_page;
        check(current_page);
    });
});
var max_page = $('.question-item').attr('data-length');
var current_page = 1;



//查看试题
function check(page){
    if(page==undefined){
        page = current_page;
    }
    $("[id^='question_']").hide();
    $("#question_"+page).show();
    $("#pre_page,#next_page").removeClass("disabled");
    if(page==1){
        $("#pre_page").addClass("disabled");
    }else if(page==max_page){
        $("#next_page").addClass("disabled");
    }
}