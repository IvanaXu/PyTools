All these .bif files are downloaded from here:

http://www.bnlearn.com/bnrepository/

Copyright 2013 Marco Scutari. The contents of this page are licensed under the Creative Commons Attribution-Share Alike License. ( http://creativecommons.org/licenses/by-sa/3.0/ )

Use bif_parser.py to produce a python module encoding the graph according to this library, and bif_inference_tester.py to test the performance and accuracy of the library on these files as well as see an example usage.