var x = 3;
console.log('x is ' + x);
x = x * x;
console.log('x is ' + x);
console.error('CPU core temperature critical');

